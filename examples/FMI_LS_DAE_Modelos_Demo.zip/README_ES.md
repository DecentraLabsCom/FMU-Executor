# FMUs de referencia con FMI-LS-DAE para DecentraLabs

Revisión: 2 de noviembre de 2026.

Este paquete contiene tres FMUs originales, sin modificar sus binarios ni sus metadatos. Incluyen el manifiesto extra/org.fmi-standard.fmi-ls-dae/fmi-ls-manifest.xml y binarios nativos para Windows x86_64 y Linux x86_64. Las arquitecturas adicionales se detallan en METADATOS_Y_PROCEDENCIA.json.

## Procedencia

- SimpleDAE.fmu y MassSpringOscillator.fmu: artefacto FMI-LS-DAE-FMUs del repositorio oficial modelica/fmi-ls-dae, commit e5b8ffa677b2ce866dd2472504466c0e39371a69.
  Ejecución: https://github.com/modelica/fmi-ls-dae/actions/runs/34615618682
  Descarga actualizada anunciada por el proyecto: https://nightly.link/modelica/fmi-ls-dae/workflows/build-fmus.yml/main/FMI-LS-DAE-FMUs.zip
- Roberts.fmu: archivo 3.0/Roberts.fmu de Reference-FMUs.zip, versión v0.0.42 del repositorio oficial modelica/Reference-FMUs.
  Descarga: https://github.com/modelica/Reference-FMUs/releases/download/v0.0.42/Reference-FMUs.zip

Las licencias originales se incluyen en LICENCIAS. Los SHA-256 de los archivos y los metadatos inspeccionados se encuentran en METADATOS_Y_PROCEDENCIA.json.

## Qué se ha comprobado

1. Se han descargado los paquetes compilados oficiales y se ha abierto cada FMU.
2. Se ha comprobado la presencia del manifiesto FMI-LS-DAE, la interfaz Model Exchange, los binarios por plataforma y las referencias a variables.
3. Se ha cargado el binario Linux x86_64 de cada FMU en un proceso de prueba.
4. Se ha activado explícitamente el modo DAE, se ha inicializado la FMU y se han leído derivadas y residuos.
5. Se han introducido valores algebraicos inconsistentes y posteriormente valores consistentes. Los tres modelos devuelven residuos no nulos en el primer caso y prácticamente cero en el segundo.

VERIFICACION_LINUX.json contiene los resultados. Esta prueba básica NO integra una trayectoria completa, NO sustituye una validación XSD exhaustiva y NO certifica la integración con DecentraLabs. Los binarios Windows se han identificado dentro de los archivos, pero no se han ejecutado.

## 1. SimpleDAE: validación del importador y del solucionador algebraico

- FMI 3.0 Model Exchange; dos estados diferenciales x1/x2, dos variables algebraicas z1/z2, dos entradas u1/u2 y dos salidas y1/y2.
- Activación: Boolean estructural ODE_DAE_Switch, valueReference 13. Resolverlo a partir de EnableDAEParameter y establecerlo en Configuration Mode.
- Algebraicas: VR 5 y 6. Residuos: VR 11 y 12.
- Experimento declarado: inicio 0, fin 5, stepSize 1e-4.
- Útil para comprobar lectura del manifiesto, escritura de variables algebraicas y evaluación de dos restricciones no lineales.

Detalles relevantes:
- Los valores iniciales aproximados z1=z2=0 NO son consistentes: el segundo residuo vale 1/3. Con las entradas iniciales u1=u2=0 y x1=x2=0.5, una solución es z1=0 y z2=2*asin(1/3)=0.6796738189082439.
- Con las dos entradas iniciales a cero, las salidas y1/y2 son cero, aunque los estados evolucionen. La apariencia de las salidas por defecto es poco adecuada para una demo.
- El XML declara providesDirectionalDerivatives=false y providesAdjointDerivatives=false, aunque el README del repositorio dice lo contrario. Atender a las capacidades del XML.
- En el código fuente, el modo ODE fija z1=z2=0 como solución provisional; NO usar sus trayectorias ODE como referencia de equivalencia con el modo DAE.
- Las pruebas de integración DAE de la CI de origen están marcadas como pendientes; las comprobaciones automáticas de simulación de origen usan modo ODE.

Fuente: https://github.com/modelica/fmi-ls-dae/tree/e5b8ffa677b2ce866dd2472504466c0e39371a69/reference-FMUs/SimpleDAE

## 2. MassSpringOscillator: el candidato más intuitivo para una demo física

Sistema masa-muelle sin amortiguamiento:
- dx/dt = v
- dv/dt = F/m
- 0 = F + k*x
- E = (m*v*v + k*x*x)/2

- FMI 3.0 Model Exchange; dos estados x/v y una variable algebraica F.
- Activación: ODE_DAE_Switch, VR 10.
- Algebraica F: VR 5. Residuo: VR 9. Energía E: VR 8.
- Experimento declarado: inicio 0, fin 20, stepSize 1e-3.
- Con m=k=1, x(0)=1 y v(0)=0: x(t)=cos(t), v(t)=-sin(t), F(t)=-cos(t), E=0.5.

Detalles relevantes:
- El único valor declarado causality=output es E. x/v/F son variables locales. Una interfaz que publique únicamente salidas verá una energía casi constante; una animación necesita lectura autorizada de x/v o una exportación que los publique como salidas.
- El manifiesto incluye un elemento Invariant. El XSD de la etiqueta publicada v1.0.0-alpha.1 NO contempla ese elemento, aunque el manifiesto declare esa misma versión. Un validador estricto puede rechazarlo por esta discrepancia entre el ejemplo de desarrollo y el esquema publicado.
- El soporte del elemento Invariant debe tratarse explícitamente; no es necesario implementar proyección de energía para resolver la DAE.
- Las pruebas de integración DAE de la CI de origen están marcadas como pendientes; las comprobaciones de simulación de origen usan modo ODE.
- En modo DAE el importador debe asegurar F=-k*x. En la prueba se ha escrito explícitamente F=-1 con el estado inicial por defecto.

Fuente: https://github.com/modelica/fmi-ls-dae/tree/e5b8ffa677b2ce866dd2472504466c0e39371a69/reference-FMUs/MassSpringOscillator

## 3. Roberts: cinética química rígida y validación numérica exigente

Problema de Robertson:
- dy1/dt = -0.04*y1 + 1e4*y2*y3
- dy2/dt = 0.04*y1 - 1e4*y2*y3 - 3e7*y2*y2
- 0 = y1+y2+y3-1

- Incluye FMI 3.0 Model Exchange Y Co-Simulation. Seleccionar expresamente Model Exchange + modo DAE; ejecutar Co-Simulation no valida el importador LS-DAE.
- Activación: Boolean estructural dae, VR 1.
- Algebraica y3: VR 6. Residuo r: VR 7.
- Publica y1/y2/y3 como salidas, adecuadas para una demo con gráficas de concentraciones.
- Incluye una serie de referencia en extra/org.fmi-standard.fmi-ls-ref/Roberts_out.csv.
- El DefaultExperiment tiene inicio 1e-5, fin 1e8 y tolerance=1e-4. Ese horizonte es muy grande para una demo inicial: configurar un intervalo acotado deliberadamente.

Defectos observados en el manifiesto original de v0.0.42:
- El manifiesto DAE declara EventIndicator con VR 9 y 10; en modelDescription.xml los indicadores son VR 8 y 9, y NO existe VR 10. Un importador que compruebe referencias debería detectarlo.
- El atributo fmi-ls-description dice 'Layered standard for DAE support in FMI 3'; el XSD publicado fija la cadena 'Layered standard for DAE support in FMI.'. La validación XSD estricta también puede fallar aquí.
- Se han conservado los metadatos originales para no presentar una corrección local como una distribución oficial.
- El éxito de la prueba numérica puntual no elimina estos defectos del manifiesto.

Fuente: https://github.com/modelica/Reference-FMUs/tree/v0.0.42/Roberts

## Orden sugerido

1. SimpleDAE para importación y resolución algebraica básica.
2. MassSpringOscillator para comparar contra solución analítica y preparar una demo física, resolviendo primero la publicación de estados y la política de Invariant.
3. Roberts para rigidez, escalado y gráficas, corrigiendo primero las referencias inconsistentes de su manifiesto.

Para demostrar que se está usando el LS, registrar el backend seleccionado (Model Exchange), el valor del parámetro de activación y una medida del residuo algebraico. Obtener una trayectoria con el modo ODE o Co-Simulation no acredita ejecución DAE.

